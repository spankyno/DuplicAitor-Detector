using System.Collections.ObjectModel;
using Avalonia.Controls;
using Avalonia.Platform.Storage;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using DuplicAitorDetector.Models;
using DuplicAitorDetector.Services;

namespace DuplicAitorDetector.ViewModels;

public partial class MainViewModel : ViewModelBase
{
    private readonly IScanService _scanService;
    private readonly ExportService _exportService = new();
    private readonly ProfileService _profileService = new();
    private CancellationTokenSource? _cts;
    private Window? _hostWindow;
    private ScanResult? _lastResult;

    public MainViewModel()
    {
        Profile = new ScanProfile();
        Logs = new ObservableCollection<string>();
        ExactGroups = new ObservableCollection<DuplicateGroup>();
        ProbableGroups = new ObservableCollection<DuplicateGroup>();
        RelatedGroups = new ObservableCollection<DuplicateGroup>();
        UniqueFiles = new ObservableCollection<FileInfoItem>();

        _scanService = new ScanService();
        _scanService.LogMessage += msg => Avalonia.Threading.Dispatcher.UIThread.Post(() =>
        {
            Logs.Add(msg);
            while (Logs.Count > 500)
                Logs.RemoveAt(0);
        });
        _scanService.ProgressChanged += p => Avalonia.Threading.Dispatcher.UIThread.Post(() => Progress = p);
    }

    public void SetHostWindow(Window window) => _hostWindow = window;

    // ── Configuración ──────────────────────────────────────────
    [ObservableProperty]
    private ScanProfile _profile;

    [ObservableProperty]
    private string _newFolderPath = string.Empty;

    [ObservableProperty]
    private string _minSizeText = string.Empty;

    [ObservableProperty]
    private string _maxSizeText = string.Empty;

    // ── Estado del análisis ────────────────────────────────────
    [ObservableProperty]
    private bool _isScanning;

    [ObservableProperty]
    private bool _isPaused;

    [ObservableProperty]
    private double _progress;

    [ObservableProperty]
    private string _statusText = "Listo. Selecciona carpetas y pulsa Iniciar análisis.";

    [ObservableProperty]
    private bool _hasResults;

    public ObservableCollection<string> Logs { get; }

    // ── Resultados ─────────────────────────────────────────────
    [ObservableProperty]
    private ScanStatistics? _statistics;

    public ObservableCollection<DuplicateGroup> ExactGroups { get; }
    public ObservableCollection<DuplicateGroup> ProbableGroups { get; }
    public ObservableCollection<DuplicateGroup> RelatedGroups { get; }
    public ObservableCollection<FileInfoItem> UniqueFiles { get; }

    // ── Comandos de carpetas ───────────────────────────────────

    [RelayCommand]
    private async Task BrowseFolderAsync()
    {
        if (_hostWindow is null) return;

        var folders = await _hostWindow.StorageProvider.OpenFolderPickerAsync(new FolderPickerOpenOptions
        {
            Title = "Seleccionar carpeta para analizar",
            AllowMultiple = true
        });

        foreach (var folder in folders)
        {
            var path = folder.TryGetLocalPath();
            if (string.IsNullOrEmpty(path)) continue;
            if (Directory.Exists(path) && !Profile.RootFolders.Contains(path))
            {
                Profile.RootFolders.Add(path);
                Logs.Add($"[{DateTime.Now:HH:mm:ss}] Carpeta añadida: {path}");
            }
        }
    }

    [RelayCommand]
    private void AddFolder()
    {
        if (string.IsNullOrWhiteSpace(NewFolderPath)) return;
        var path = NewFolderPath.Trim().Trim('"');
        if (Directory.Exists(path) && !Profile.RootFolders.Contains(path))
        {
            Profile.RootFolders.Add(path);
            NewFolderPath = string.Empty;
            Logs.Add($"[{DateTime.Now:HH:mm:ss}] Carpeta añadida: {path}");
        }
        else
        {
            Logs.Add($"[{DateTime.Now:HH:mm:ss}] Carpeta no válida o ya añadida: {path}");
        }
    }

    [RelayCommand]
    private void RemoveFolder(string? folder)
    {
        if (folder is null) return;
        if (Profile.RootFolders.Remove(folder))
            Logs.Add($"[{DateTime.Now:HH:mm:ss}] Carpeta eliminada de la lista: {folder}");
    }

    [RelayCommand]
    private async Task BrowseComparisonFolderAAsync()
    {
        if (_hostWindow is null) return;
        var folders = await _hostWindow.StorageProvider.OpenFolderPickerAsync(new FolderPickerOpenOptions
        {
            Title = "Seleccionar Carpeta A",
            AllowMultiple = false
        });
        if (folders.Count > 0)
        {
            var path = folders[0].TryGetLocalPath();
            if (!string.IsNullOrEmpty(path))
                Profile.ComparisonFolderA = path;
        }
    }

    [RelayCommand]
    private async Task BrowseComparisonFolderBAsync()
    {
        if (_hostWindow is null) return;
        var folders = await _hostWindow.StorageProvider.OpenFolderPickerAsync(new FolderPickerOpenOptions
        {
            Title = "Seleccionar Carpeta B",
            AllowMultiple = false
        });
        if (folders.Count > 0)
        {
            var path = folders[0].TryGetLocalPath();
            if (!string.IsNullOrEmpty(path))
                Profile.ComparisonFolderB = path;
        }
    }

    // ── Análisis ───────────────────────────────────────────────

    [RelayCommand]
    private async Task StartScanAsync()
    {
        if (IsScanning) return;

        Profile.MinSizeBytes = ParseSize(MinSizeText);
        Profile.MaxSizeBytes = ParseSize(MaxSizeText);

        if (Profile.RootFolders.Count == 0 && !Profile.CompareTwoLocations)
        {
            StatusText = "Añade al menos una carpeta antes de iniciar el análisis.";
            return;
        }

        if (Profile.CompareTwoLocations &&
            string.IsNullOrWhiteSpace(Profile.ComparisonFolderA) &&
            string.IsNullOrWhiteSpace(Profile.ComparisonFolderB) &&
            Profile.RootFolders.Count == 0)
        {
            StatusText = "En modo comparación indica al menos una carpeta.";
            return;
        }

        IsScanning = true;
        IsPaused = false;
        Progress = 0;
        Logs.Clear();
        ExactGroups.Clear();
        ProbableGroups.Clear();
        RelatedGroups.Clear();
        UniqueFiles.Clear();
        Statistics = null;
        HasResults = false;
        _lastResult = null;
        StatusText = "Analizando... (solo lectura)";

        _cts = new CancellationTokenSource();

        try
        {
            var result = await _scanService.ScanAsync(Profile, _cts.Token);
            _lastResult = result;

            foreach (var g in result.ExactDuplicates) ExactGroups.Add(g);
            foreach (var g in result.ProbableDuplicates) ProbableGroups.Add(g);
            foreach (var g in result.RelatedFiles) RelatedGroups.Add(g);
            foreach (var f in result.UniqueFiles) UniqueFiles.Add(f);
            Statistics = result.Statistics;
            HasResults = true;

            StatusText = $"Análisis completado. {result.Statistics.ExactDuplicateGroups} exactos · {result.Statistics.ProbableDuplicateGroups} probables · Ahorro: {result.Statistics.PotentialSavingsFormatted}";
        }
        catch (OperationCanceledException)
        {
            StatusText = "Análisis cancelado.";
            Logs.Add($"[{DateTime.Now:HH:mm:ss}] Análisis cancelado por el usuario.");
        }
        catch (Exception ex)
        {
            StatusText = "Error durante el análisis.";
            Logs.Add($"[{DateTime.Now:HH:mm:ss}] ERROR: {ex.Message}");
        }
        finally
        {
            IsScanning = false;
            IsPaused = false;
            _cts?.Dispose();
            _cts = null;
        }
    }

    [RelayCommand]
    private void CancelScan()
    {
        _cts?.Cancel();
    }

    [RelayCommand]
    private void TogglePause()
    {
        if (!IsScanning) return;
        if (IsPaused)
        {
            _scanService.Resume();
            IsPaused = false;
            StatusText = "Analizando... (reanudado)";
        }
        else
        {
            _scanService.Pause();
            IsPaused = true;
            StatusText = "Análisis pausado.";
        }
    }

    [RelayCommand]
    private void ClearResults()
    {
        ExactGroups.Clear();
        ProbableGroups.Clear();
        RelatedGroups.Clear();
        UniqueFiles.Clear();
        Statistics = null;
        HasResults = false;
        _lastResult = null;
        Logs.Clear();
        Progress = 0;
        StatusText = "Resultados limpiados. Listo para un nuevo análisis.";
    }

    // ── Exportación ────────────────────────────────────────────

    [RelayCommand]
    private async Task ExportHtmlAsync()
    {
        if (_lastResult is null || _hostWindow is null)
        {
            StatusText = "No hay resultados para exportar. Ejecuta un análisis primero.";
            return;
        }

        var file = await _hostWindow.StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
        {
            Title = "Exportar informe HTML",
            SuggestedFileName = $"DuplicAitor_{DateTime.Now:yyyyMMdd_HHmm}.html",
            DefaultExtension = "html",
            FileTypeChoices = new[]
            {
                new FilePickerFileType("HTML") { Patterns = new[] { "*.html" } }
            }
        });

        if (file is null) return;
        var path = file.TryGetLocalPath();
        if (string.IsNullOrEmpty(path)) return;

        try
        {
            await _exportService.ExportHtmlAsync(path, _lastResult, Profile);
            StatusText = $"Informe HTML exportado: {path}";
            Logs.Add($"[{DateTime.Now:HH:mm:ss}] Exportado HTML → {path}");
        }
        catch (Exception ex)
        {
            StatusText = "Error al exportar HTML.";
            Logs.Add($"[{DateTime.Now:HH:mm:ss}] ERROR export HTML: {ex.Message}");
        }
    }

    [RelayCommand]
    private async Task ExportJsonAsync()
    {
        if (_lastResult is null || _hostWindow is null)
        {
            StatusText = "No hay resultados para exportar. Ejecuta un análisis primero.";
            return;
        }

        var file = await _hostWindow.StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
        {
            Title = "Exportar resultados JSON",
            SuggestedFileName = $"DuplicAitor_{DateTime.Now:yyyyMMdd_HHmm}.json",
            DefaultExtension = "json",
            FileTypeChoices = new[]
            {
                new FilePickerFileType("JSON") { Patterns = new[] { "*.json" } }
            }
        });

        if (file is null) return;
        var path = file.TryGetLocalPath();
        if (string.IsNullOrEmpty(path)) return;

        try
        {
            await _exportService.ExportJsonAsync(path, _lastResult, Profile);
            StatusText = $"Resultados JSON exportados: {path}";
            Logs.Add($"[{DateTime.Now:HH:mm:ss}] Exportado JSON → {path}");
        }
        catch (Exception ex)
        {
            StatusText = "Error al exportar JSON.";
            Logs.Add($"[{DateTime.Now:HH:mm:ss}] ERROR export JSON: {ex.Message}");
        }
    }


    [RelayCommand]
    private async Task ExportPdfAsync()
    {
        if (_lastResult is null || _hostWindow is null)
        {
            StatusText = "No hay resultados para exportar. Ejecuta un análisis primero.";
            return;
        }

        var file = await _hostWindow.StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
        {
            Title = "Exportar informe PDF",
            SuggestedFileName = $"DuplicAitor_{DateTime.Now:yyyyMMdd_HHmm}.pdf",
            DefaultExtension = "pdf",
            FileTypeChoices = new[]
            {
                new FilePickerFileType("PDF") { Patterns = new[] { "*.pdf" } }
            }
        });

        if (file is null) return;
        var path = file.TryGetLocalPath();
        if (string.IsNullOrEmpty(path)) return;

        try
        {
            await _exportService.ExportPdfAsync(path, _lastResult, Profile);
            StatusText = $"Informe PDF exportado: {path}";
            Logs.Add($"[{DateTime.Now:HH:mm:ss}] Exportado PDF → {path}");
        }
        catch (Exception ex)
        {
            StatusText = "Error al exportar PDF.";
            Logs.Add($"[{DateTime.Now:HH:mm:ss}] ERROR export PDF: {ex.Message}");
        }
    }

    // ── Perfiles ───────────────────────────────────────────────

    [RelayCommand]
    private async Task SaveProfileAsync()
    {
        if (_hostWindow is null) return;

        var file = await _hostWindow.StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
        {
            Title = "Guardar perfil de análisis",
            SuggestedFileName = string.IsNullOrWhiteSpace(Profile.Name) ? "perfil.json" : SanitizeFileName(Profile.Name) + ".json",
            DefaultExtension = "json",
            FileTypeChoices = new[]
            {
                new FilePickerFileType("Perfil JSON") { Patterns = new[] { "*.json" } }
            }
        });

        if (file is null) return;
        var path = file.TryGetLocalPath();
        if (string.IsNullOrEmpty(path)) return;

        try
        {
            Profile.MinSizeBytes = ParseSize(MinSizeText);
            Profile.MaxSizeBytes = ParseSize(MaxSizeText);
            await _profileService.SaveToPathAsync(Profile, path);
            StatusText = $"Perfil guardado: {path}";
            Logs.Add($"[{DateTime.Now:HH:mm:ss}] Perfil guardado → {path}");
        }
        catch (Exception ex)
        {
            StatusText = "Error al guardar perfil.";
            Logs.Add($"[{DateTime.Now:HH:mm:ss}] ERROR guardar perfil: {ex.Message}");
        }
    }

    [RelayCommand]
    private async Task LoadProfileAsync()
    {
        if (_hostWindow is null) return;

        var files = await _hostWindow.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
        {
            Title = "Cargar perfil de análisis",
            AllowMultiple = false,
            FileTypeFilter = new[]
            {
                new FilePickerFileType("Perfil JSON") { Patterns = new[] { "*.json" } }
            }
        });

        if (files.Count == 0) return;
        var path = files[0].TryGetLocalPath();
        if (string.IsNullOrEmpty(path)) return;

        try
        {
            var loaded = await _profileService.LoadFromPathAsync(path);
            if (loaded is null)
            {
                StatusText = "No se pudo leer el perfil.";
                return;
            }

            Profile = loaded;
            MinSizeText = loaded.MinSizeBytes.HasValue ? loaded.MinSizeBytes.Value.ToString() : string.Empty;
            MaxSizeText = loaded.MaxSizeBytes.HasValue ? loaded.MaxSizeBytes.Value.ToString() : string.Empty;
            StatusText = $"Perfil cargado: {loaded.Name}";
            Logs.Add($"[{DateTime.Now:HH:mm:ss}] Perfil cargado ← {path} ({loaded.RootFolders.Count} carpetas)");
        }
        catch (Exception ex)
        {
            StatusText = "Error al cargar perfil.";
            Logs.Add($"[{DateTime.Now:HH:mm:ss}] ERROR cargar perfil: {ex.Message}");
        }
    }

    // ── Drag & Drop ────────────────────────────────────────────

    public void AddFolderFromDrop(string path)
    {
        if (string.IsNullOrWhiteSpace(path)) return;
        path = path.Trim().Trim('"');
        if (Directory.Exists(path) && !Profile.RootFolders.Contains(path))
        {
            Profile.RootFolders.Add(path);
            Logs.Add($"[{DateTime.Now:HH:mm:ss}] Carpeta añadida (arrastre): {path}");
        }
        else if (File.Exists(path))
        {
            var dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir) && Directory.Exists(dir) && !Profile.RootFolders.Contains(dir))
            {
                Profile.RootFolders.Add(dir);
                Logs.Add($"[{DateTime.Now:HH:mm:ss}] Carpeta del archivo añadida (arrastre): {dir}");
            }
        }
    }

    private static long? ParseSize(string? text)
    {
        if (string.IsNullOrWhiteSpace(text)) return null;
        text = text.Trim().Replace(" ", "").ToLowerInvariant();

        long multiplier = 1;
        if (text.EndsWith("kb"))
        {
            multiplier = 1024;
            text = text[..^2];
        }
        else if (text.EndsWith("mb"))
        {
            multiplier = 1024 * 1024;
            text = text[..^2];
        }
        else if (text.EndsWith("gb"))
        {
            multiplier = 1024L * 1024 * 1024;
            text = text[..^2];
        }

        if (long.TryParse(text, out var value) && value >= 0)
            return value * multiplier;

        return null;
    }

    private static string SanitizeFileName(string name)
    {
        foreach (var c in Path.GetInvalidFileNameChars())
            name = name.Replace(c, '_');
        return string.IsNullOrWhiteSpace(name) ? "perfil" : name.Trim();
    }
}
