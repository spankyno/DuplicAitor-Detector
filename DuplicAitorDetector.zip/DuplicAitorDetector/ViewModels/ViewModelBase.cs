using CommunityToolkit.Mvvm.ComponentModel;

namespace DuplicAitorDetector.ViewModels;

public abstract class ViewModelBase : ObservableObject
{
}
