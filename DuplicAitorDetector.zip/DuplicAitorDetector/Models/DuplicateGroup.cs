namespace DuplicAitorDetector.Models;

public enum DuplicateType
{
    Exact,          // Mismo hash
    Probable,       // Alta similitud
    Related,        // Mismo nombre / metadatos
    Unique
}

public class DuplicateGroup
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N")[..8];
    public DuplicateType Type { get; set; }
    public List<FileInfoItem> Files { get; set; } = new();
    public long TotalSizeBytes => Files.Sum(f => f.SizeBytes);
    public long RecoverableBytes => Files.Count > 1
        ? TotalSizeBytes - Files.Max(f => f.SizeBytes)
        : 0;
    public string SizeFormatted => FormatSize(TotalSizeBytes);
    public string RecoverableFormatted => FormatSize(RecoverableBytes);

    private static string FormatSize(long bytes)
    {
        string[] suffixes = ["B", "KB", "MB", "GB", "TB"];
        int i = 0;
        double size = bytes;
        while (size >= 1024 && i < suffixes.Length - 1)
        {
            size /= 1024;
            i++;
        }
        return $"{size:0.##} {suffixes[i]}";
    }
}
