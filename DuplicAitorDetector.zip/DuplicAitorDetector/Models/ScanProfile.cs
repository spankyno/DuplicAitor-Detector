using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;

namespace DuplicAitorDetector.Models;

/// <summary>
/// Perfil de análisis configurable (guardable/cargable en JSON).
/// </summary>
public partial class ScanProfile : ObservableObject
{
    [ObservableProperty]
    private string _name = "Perfil por defecto";

    public ObservableCollection<string> RootFolders { get; } = new();

    [ObservableProperty]
    private bool _includeSubfolders = true;

    public List<string> ExcludedFolders { get; set; } = new();
    public List<string> IncludedExtensions { get; set; } = new();
    public List<string> ExcludedExtensions { get; set; } = new();

    [ObservableProperty]
    private long? _minSizeBytes;

    [ObservableProperty]
    private long? _maxSizeBytes;

    public DateTime? ModifiedAfter { get; set; }
    public DateTime? ModifiedBefore { get; set; }

    [ObservableProperty]
    private string? _nameIncludePattern;

    [ObservableProperty]
    private string? _nameExcludePattern;

    [ObservableProperty]
    private bool _compareTwoLocations;

    [ObservableProperty]
    private string? _comparisonFolderA;

    [ObservableProperty]
    private string? _comparisonFolderB;
}
