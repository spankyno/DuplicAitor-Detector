namespace DuplicAitorDetector.Models;

public class ScanStatistics
{
    public long TotalBytesScanned { get; set; }
    public int TotalFilesScanned { get; set; }
    public int ExactDuplicateGroups { get; set; }
    public int ProbableDuplicateGroups { get; set; }
    public int RelatedGroups { get; set; }
    public int UniqueFiles { get; set; }
    public long PotentialSavingsBytes { get; set; }

    public string TotalScannedFormatted => FormatSize(TotalBytesScanned);
    public string PotentialSavingsFormatted => FormatSize(PotentialSavingsBytes);

    private static string FormatSize(long bytes)
    {
        string[] suffixes = ["B", "KB", "MB", "GB", "TB"];
        int i = 0;
        double size = bytes;
        while (size >= 1024 && i < suffixes.Length - 1)
        {
            size /= 1024;
            i++;
        }
        return $"{size:0.##} {suffixes[i]}";
    }
}
