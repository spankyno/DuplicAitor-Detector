using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Platform.Storage;
using DuplicAitorDetector.ViewModels;

namespace DuplicAitorDetector.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();

        // Habilitar Drag & Drop
        AddHandler(DragDrop.DropEvent, OnDrop);
        AddHandler(DragDrop.DragOverEvent, OnDragOver);

        // Pasar la ventana al ViewModel para diálogos nativos
        DataContextChanged += (_, _) =>
        {
            if (DataContext is MainViewModel vm)
                vm.SetHostWindow(this);
        };

        // Por si el DataContext ya está asignado
        if (DataContext is MainViewModel existing)
            existing.SetHostWindow(this);
    }

    private void OnDragOver(object? sender, DragEventArgs e)
    {
        e.DragEffects = e.Data.Contains(DataFormats.Files)
            ? DragDropEffects.Copy
            : DragDropEffects.None;
    }

    private void OnDrop(object? sender, DragEventArgs e)
    {
        if (DataContext is not MainViewModel vm) return;
        if (!e.Data.Contains(DataFormats.Files)) return;

        var files = e.Data.GetFiles();
        if (files is null) return;

        foreach (var item in files)
        {
            var path = item.TryGetLocalPath();
            if (!string.IsNullOrEmpty(path))
                vm.AddFolderFromDrop(path);
        }
    }
}
