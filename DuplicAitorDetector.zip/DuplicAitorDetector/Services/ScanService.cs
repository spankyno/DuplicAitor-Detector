using System.Security.Cryptography;
using DuplicAitorDetector.Models;

namespace DuplicAitorDetector.Services;

/// <summary>
/// Servicio de análisis de solo lectura. Nunca modifica el sistema de archivos.
/// </summary>
public class ScanService : IScanService
{
    public event Action<string>? LogMessage;
    public event Action<double>? ProgressChanged;

    private volatile bool _isPaused;
    private readonly HashCacheService _cache = new();

    public void Pause()
    {
        _isPaused = true;
        Log("Análisis pausado por el usuario.");
    }

    public void Resume()
    {
        _isPaused = false;
        Log("Análisis reanudado.");
    }

    public async Task<ScanResult> ScanAsync(ScanProfile profile, CancellationToken cancellationToken = default)
    {
        var result = new ScanResult();
        var allFiles = new List<FileInfoItem>();

        Log("Iniciando escaneo de solo lectura...");
        Log($"Caché de hashes: {_cache.Count} entradas previas.");

        var folders = profile.RootFolders.ToList();
        if (profile.CompareTwoLocations)
        {
            if (!string.IsNullOrWhiteSpace(profile.ComparisonFolderA))
                folders.Add(profile.ComparisonFolderA);
            if (!string.IsNullOrWhiteSpace(profile.ComparisonFolderB))
                folders.Add(profile.ComparisonFolderB);
        }

        folders = folders.Where(Directory.Exists).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        if (folders.Count == 0)
        {
            Log("No se encontraron carpetas válidas para escanear.");
            return result;
        }

        // 1. Enumerar archivos (solo lectura)
        Log($"Enumerando archivos en {folders.Count} ubicación(es)...");
        var filePaths = new List<string>();

        foreach (var folder in folders)
        {
            cancellationToken.ThrowIfCancellationRequested();
            await WaitIfPausedAsync(cancellationToken);

            try
            {
                var options = new EnumerationOptions
                {
                    RecurseSubdirectories = profile.IncludeSubfolders,
                    IgnoreInaccessible = true,
                    AttributesToSkip = FileAttributes.System | FileAttributes.Temporary
                };

                foreach (var path in Directory.EnumerateFiles(folder, "*", options))
                {
                    cancellationToken.ThrowIfCancellationRequested();

                    if (IsExcluded(path, profile))
                        continue;

                    if (!MatchesFilters(path, profile))
                        continue;

                    filePaths.Add(path);
                }
            }
            catch (Exception ex)
            {
                Log($"Error al enumerar {folder}: {ex.Message}");
            }
        }

        Log($"Se encontraron {filePaths.Count} archivos candidatos.");
        if (filePaths.Count == 0)
        {
            ProgressChanged?.Invoke(1.0);
            Log("No hay archivos que analizar.");
            return result;
        }

        // 2. Metadatos + hash (con caché)
        Log("Calculando hashes SHA-256 (solo lectura, con caché)...");
        int processed = 0;
        int cacheHits = 0;
        var lockObj = new object();
        const int maxDegree = 4;

        await Parallel.ForEachAsync(
            filePaths,
            new ParallelOptions
            {
                MaxDegreeOfParallelism = maxDegree,
                CancellationToken = cancellationToken
            },
            async (path, ct) =>
            {
                await WaitIfPausedAsync(ct);

                try
                {
                    var fi = new FileInfo(path);
                    if (!fi.Exists) return;

                    var item = new FileInfoItem
                    {
                        FullPath = path,
                        SizeBytes = fi.Length,
                        LastWriteTime = fi.LastWriteTimeUtc
                    };

                    // Intentar caché
                    var cached = _cache.TryGet(path, fi.Length, fi.LastWriteTimeUtc);
                    if (cached is not null)
                    {
                        item.HashSha256 = cached;
                        Interlocked.Increment(ref cacheHits);
                    }
                    else
                    {
                        item.HashSha256 = await ComputeHashAsync(path, ct);
                        _cache.Set(path, fi.Length, fi.LastWriteTimeUtc, item.HashSha256);
                    }

                    lock (lockObj)
                    {
                        allFiles.Add(item);
                    }
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    Log($"No se pudo procesar {path}: {ex.Message}");
                }

                var current = Interlocked.Increment(ref processed);
                ProgressChanged?.Invoke((double)current / filePaths.Count);
                if (current % 50 == 0 || current == filePaths.Count)
                    Log($"Procesados {current}/{filePaths.Count} archivos...");
            });

        _cache.SaveIfDirty();
        Log($"Hashes desde caché: {cacheHits}/{allFiles.Count} ({(allFiles.Count > 0 ? 100.0 * cacheHits / allFiles.Count : 0):0.#}%).");

        // 3. Agrupar por hash exacto
        Log("Agrupando duplicados exactos...");
        var exactGroups = allFiles
            .Where(f => !string.IsNullOrEmpty(f.HashSha256))
            .GroupBy(f => f.HashSha256!)
            .Where(g => g.Count() > 1)
            .Select(g => new DuplicateGroup
            {
                Type = DuplicateType.Exact,
                Files = g.OrderByDescending(f => f.SizeBytes).ToList()
            })
            .OrderByDescending(g => g.RecoverableBytes)
            .ToList();

        result.ExactDuplicates = exactGroups;

        var exactPaths = exactGroups.SelectMany(g => g.Files).Select(f => f.FullPath).ToHashSet(StringComparer.OrdinalIgnoreCase);

        // 4. Duplicados probables: mismo tamaño + nombre similar, distinto hash
        Log("Detectando duplicados probables (mismo tamaño + nombre similar)...");
        var candidates = allFiles.Where(f => !exactPaths.Contains(f.FullPath)).ToList();
        var probableGroups = FindProbableDuplicates(candidates);
        result.ProbableDuplicates = probableGroups;
        var probablePaths = probableGroups.SelectMany(g => g.Files).Select(f => f.FullPath).ToHashSet(StringComparer.OrdinalIgnoreCase);

        // 5. Relacionados por nombre exacto (quedan fuera de exactos y probables)
        Log("Detectando archivos relacionados (mismo nombre)...");
        var relatedGroups = allFiles
            .Where(f => !exactPaths.Contains(f.FullPath) && !probablePaths.Contains(f.FullPath))
            .GroupBy(f => Path.GetFileName(f.FullPath).ToLowerInvariant())
            .Where(g => g.Count() > 1)
            .Select(g => new DuplicateGroup
            {
                Type = DuplicateType.Related,
                Files = g.OrderByDescending(f => f.SizeBytes).ToList()
            })
            .OrderByDescending(g => g.Files.Count)
            .ToList();

        result.RelatedFiles = relatedGroups;
        var relatedPaths = relatedGroups.SelectMany(g => g.Files).Select(f => f.FullPath).ToHashSet(StringComparer.OrdinalIgnoreCase);

        // 6. Únicos
        result.UniqueFiles = allFiles
            .Where(f => !exactPaths.Contains(f.FullPath)
                        && !probablePaths.Contains(f.FullPath)
                        && !relatedPaths.Contains(f.FullPath))
            .OrderBy(f => f.FullPath)
            .ToList();

        // 7. Estadísticas
        result.Statistics = new ScanStatistics
        {
            TotalFilesScanned = allFiles.Count,
            TotalBytesScanned = allFiles.Sum(f => f.SizeBytes),
            ExactDuplicateGroups = exactGroups.Count,
            ProbableDuplicateGroups = probableGroups.Count,
            RelatedGroups = relatedGroups.Count,
            UniqueFiles = result.UniqueFiles.Count,
            PotentialSavingsBytes = exactGroups.Sum(g => g.RecoverableBytes)
                                   + probableGroups.Sum(g => g.RecoverableBytes)
        };

        ProgressChanged?.Invoke(1.0);
        Log($"Análisis completado. {exactGroups.Count} exactos, {probableGroups.Count} probables, {relatedGroups.Count} relacionados. Ningún archivo fue modificado.");
        return result;
    }

    /// <summary>
    /// Agrupa archivos con el mismo tamaño exacto y nombre normalizado similar
    /// (ignorando sufijos tipo "copia", "(1)", "_v2", etc.). Distinto hash.
    /// </summary>
    private static List<DuplicateGroup> FindProbableDuplicates(List<FileInfoItem> files)
    {
        // Primero agrupar por tamaño exacto (señal fuerte)
        var bySize = files
            .Where(f => f.SizeBytes > 0)
            .GroupBy(f => f.SizeBytes)
            .Where(g => g.Count() > 1)
            .ToList();

        var groups = new List<DuplicateGroup>();
        var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var sizeGroup in bySize)
        {
            var list = sizeGroup.Where(f => !used.Contains(f.FullPath)).ToList();
            if (list.Count < 2) continue;

            // Sub-agrupar por nombre normalizado
            var byName = list
                .GroupBy(f => NormalizeFileName(Path.GetFileNameWithoutExtension(f.FullPath)))
                .Where(g => g.Count() > 1 && !string.IsNullOrEmpty(g.Key));

            foreach (var nameGroup in byName)
            {
                var members = nameGroup.ToList();
                // Deben tener al menos 2 hashes distintos (si todos mismo hash ya serían exactos)
                var distinctHashes = members.Select(m => m.HashSha256).Where(h => h != null).Distinct().Count();
                if (distinctHashes < 1 && members.Count < 2) continue;

                // Si todos tienen el mismo hash no deberían llegar aquí, pero por seguridad:
                if (distinctHashes == 1 && members.All(m => m.HashSha256 == members[0].HashSha256))
                    continue;

                var group = new DuplicateGroup
                {
                    Type = DuplicateType.Probable,
                    Files = members.OrderByDescending(f => f.SizeBytes).ToList()
                };
                groups.Add(group);
                foreach (var m in members)
                    used.Add(m.FullPath);
            }
        }

        // Segundo pase: nombres muy similares (Levenshtein) y tamaño ±2%
        var remaining = files.Where(f => !used.Contains(f.FullPath) && f.SizeBytes > 1024).ToList();
        for (int i = 0; i < remaining.Count; i++)
        {
            if (used.Contains(remaining[i].FullPath)) continue;
            var cluster = new List<FileInfoItem> { remaining[i] };
            var nameI = NormalizeFileName(Path.GetFileNameWithoutExtension(remaining[i].FullPath));
            if (string.IsNullOrEmpty(nameI) || nameI.Length < 4) continue;

            for (int j = i + 1; j < remaining.Count; j++)
            {
                if (used.Contains(remaining[j].FullPath)) continue;
                var sizeDiff = Math.Abs(remaining[i].SizeBytes - remaining[j].SizeBytes);
                var maxSize = Math.Max(remaining[i].SizeBytes, remaining[j].SizeBytes);
                if (maxSize == 0 || (double)sizeDiff / maxSize > 0.02) continue;

                var nameJ = NormalizeFileName(Path.GetFileNameWithoutExtension(remaining[j].FullPath));
                if (string.IsNullOrEmpty(nameJ)) continue;

                if (NameSimilarity(nameI, nameJ) >= 0.85)
                    cluster.Add(remaining[j]);
            }

            if (cluster.Count >= 2)
            {
                groups.Add(new DuplicateGroup
                {
                    Type = DuplicateType.Probable,
                    Files = cluster.OrderByDescending(f => f.SizeBytes).ToList()
                });
                foreach (var m in cluster)
                    used.Add(m.FullPath);
            }
        }

        return groups.OrderByDescending(g => g.RecoverableBytes).ToList();
    }

    private static string NormalizeFileName(string name)
    {
        if (string.IsNullOrWhiteSpace(name)) return string.Empty;
        name = name.ToLowerInvariant();

        // Quitar sufijos comunes de copia/versión
        string[] patterns =
        {
            @"[\s_\-\.]*\(copia\)",
            @"[\s_\-\.]*\(copy\)",
            @"[\s_\-\.]*copy",
            @"[\s_\-\.]*copia",
            @"[\s_\-\.]*\(\d+\)",
            @"[\s_\-\.]*\[\d+\]",
            @"[\s_\-\.]*_v?\d+$",
            @"[\s_\-\.]*\-v?\d+$",
            @"[\s_\-\.]*final$",
            @"[\s_\-\.]*editado$",
            @"[\s_\-\.]*edited$",
            @"[\s_\-\.]*backup$",
            @"[\s_\-\.]*bak$"
        };
        foreach (var p in patterns)
            name = System.Text.RegularExpressions.Regex.Replace(name, p, "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);

        // Solo alfanuméricos para comparar
        name = System.Text.RegularExpressions.Regex.Replace(name, @"[^a-z0-9]", "");
        return name.Trim();
    }

    /// <summary>Similitud 0–1 basada en distancia de Levenshtein normalizada.</summary>
    private static double NameSimilarity(string a, string b)
    {
        if (a == b) return 1.0;
        if (string.IsNullOrEmpty(a) || string.IsNullOrEmpty(b)) return 0.0;
        int maxLen = Math.Max(a.Length, b.Length);
        if (maxLen == 0) return 1.0;
        int dist = Levenshtein(a, b);
        return 1.0 - (double)dist / maxLen;
    }

    private static int Levenshtein(string s, string t)
    {
        int n = s.Length, m = t.Length;
        var d = new int[n + 1, m + 1];
        for (int i = 0; i <= n; i++) d[i, 0] = i;
        for (int j = 0; j <= m; j++) d[0, j] = j;
        for (int i = 1; i <= n; i++)
        {
            for (int j = 1; j <= m; j++)
            {
                int cost = s[i - 1] == t[j - 1] ? 0 : 1;
                d[i, j] = Math.Min(Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1), d[i - 1, j - 1] + cost);
            }
        }
        return d[n, m];
    }

    private async Task WaitIfPausedAsync(CancellationToken ct)
    {
        while (_isPaused)
        {
            await Task.Delay(200, ct);
        }
    }

    private static bool IsExcluded(string path, ScanProfile profile)
    {
        foreach (var excl in profile.ExcludedFolders)
        {
            if (string.IsNullOrWhiteSpace(excl)) continue;
            if (path.StartsWith(excl.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar),
                    StringComparison.OrdinalIgnoreCase))
                return true;
        }
        return false;
    }

    private static bool MatchesFilters(string path, ScanProfile profile)
    {
        var ext = Path.GetExtension(path).ToLowerInvariant();

        if (profile.IncludedExtensions.Count > 0 &&
            !profile.IncludedExtensions.Any(e =>
            {
                var normalized = e.StartsWith('.') ? e.ToLowerInvariant() : "." + e.ToLowerInvariant();
                return normalized == ext;
            }))
            return false;

        if (profile.ExcludedExtensions.Any(e =>
            {
                var normalized = e.StartsWith('.') ? e.ToLowerInvariant() : "." + e.ToLowerInvariant();
                return normalized == ext;
            }))
            return false;

        try
        {
            var fi = new FileInfo(path);
            if (profile.MinSizeBytes.HasValue && fi.Length < profile.MinSizeBytes.Value)
                return false;
            if (profile.MaxSizeBytes.HasValue && fi.Length > profile.MaxSizeBytes.Value)
                return false;
            if (profile.ModifiedAfter.HasValue && fi.LastWriteTimeUtc < profile.ModifiedAfter.Value)
                return false;
            if (profile.ModifiedBefore.HasValue && fi.LastWriteTimeUtc > profile.ModifiedBefore.Value)
                return false;
        }
        catch
        {
            return false;
        }

        var name = Path.GetFileName(path);
        if (!string.IsNullOrWhiteSpace(profile.NameIncludePattern) &&
            !name.Contains(profile.NameIncludePattern, StringComparison.OrdinalIgnoreCase))
            return false;

        if (!string.IsNullOrWhiteSpace(profile.NameExcludePattern) &&
            name.Contains(profile.NameExcludePattern, StringComparison.OrdinalIgnoreCase))
            return false;

        return true;
    }

    private static async Task<string> ComputeHashAsync(string path, CancellationToken ct)
    {
        await using var stream = new FileStream(
            path,
            FileMode.Open,
            FileAccess.Read,
            FileShare.Read,
            bufferSize: 81920,
            useAsync: true);

        using var sha = SHA256.Create();
        var hash = await sha.ComputeHashAsync(stream, ct);
        return Convert.ToHexString(hash).ToLowerInvariant();
    }

    private void Log(string message)
    {
        LogMessage?.Invoke($"[{DateTime.Now:HH:mm:ss}] {message}");
    }
}
