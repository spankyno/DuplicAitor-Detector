using DuplicAitorDetector.Models;

namespace DuplicAitorDetector.Services;

public interface IScanService
{
    event Action<string>? LogMessage;
    event Action<double>? ProgressChanged; // 0.0 - 1.0

    Task<ScanResult> ScanAsync(ScanProfile profile, CancellationToken cancellationToken = default);
    void Pause();
    void Resume();
}

public class ScanResult
{
    public ScanStatistics Statistics { get; set; } = new();
    public List<DuplicateGroup> ExactDuplicates { get; set; } = new();
    public List<DuplicateGroup> ProbableDuplicates { get; set; } = new();
    public List<DuplicateGroup> RelatedFiles { get; set; } = new();
    public List<FileInfoItem> UniqueFiles { get; set; } = new();
}
