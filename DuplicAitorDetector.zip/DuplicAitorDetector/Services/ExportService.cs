using System.Net;
using System.Text;
using System.Text.Json;
using DuplicAitorDetector.Models;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace DuplicAitorDetector.Services;

public class ExportService
{
    private static readonly JsonSerializerOptions JsonOpts = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
    };

    static ExportService()
    {
        QuestPDF.Settings.License = LicenseType.Community;
    }

    public async Task ExportHtmlAsync(string filePath, ScanResult result, ScanProfile profile)
    {
        var sb = new StringBuilder();
        sb.AppendLine("<!DOCTYPE html>");
        sb.AppendLine("<html lang=\"es\"><head><meta charset=\"utf-8\"/>");
        sb.AppendLine("<title>DuplicAitor Detector — Informe</title>");
        sb.AppendLine("<style>");
        sb.AppendLine("body{font-family:Segoe UI,system-ui,sans-serif;background:#11111b;color:#cdd6f4;margin:0;padding:24px}");
        sb.AppendLine("h1{color:#89b4fa} h2{color:#a6e3a1;margin-top:32px}");
        sb.AppendLine(".badge{display:inline-block;background:#313244;color:#a6e3a1;padding:2px 8px;border-radius:4px;font-size:12px;margin-left:8px}");
        sb.AppendLine(".card{background:#181825;border-radius:8px;padding:16px;margin:12px 0}");
        sb.AppendLine(".stat{display:inline-block;margin:8px 24px 8px 0}");
        sb.AppendLine(".stat b{display:block;font-size:22px;color:#cdd6f4}");
        sb.AppendLine(".stat span{font-size:12px;color:#a6adc8}");
        sb.AppendLine("table{width:100%;border-collapse:collapse;margin-top:8px}");
        sb.AppendLine("th,td{text-align:left;padding:6px 10px;border-bottom:1px solid #313244;font-size:13px}");
        sb.AppendLine("th{color:#89b4fa}");
        sb.AppendLine(".path{font-family:Consolas,monospace;font-size:12px;color:#bac2de;word-break:break-all}");
        sb.AppendLine(".savings{color:#a6e3a1;font-weight:bold}");
        sb.AppendLine(".probable{color:#f9e2af}");
        sb.AppendLine("footer{margin-top:40px;color:#585b70;font-size:12px}");
        sb.AppendLine("</style></head><body>");

        sb.AppendLine("<h1>DuplicAitor Detector <span class=\"badge\">SOLO LECTURA</span></h1>");
        sb.AppendLine($"<p>Informe generado: {WebUtility.HtmlEncode(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"))}</p>");

        sb.AppendLine("<div class=\"card\"><h2 style=\"margin-top:0\">Carpetas analizadas</h2><ul>");
        foreach (var f in profile.RootFolders)
            sb.AppendLine($"<li class=\"path\">{WebUtility.HtmlEncode(f)}</li>");
        if (profile.CompareTwoLocations)
        {
            if (!string.IsNullOrEmpty(profile.ComparisonFolderA))
                sb.AppendLine($"<li class=\"path\">A: {WebUtility.HtmlEncode(profile.ComparisonFolderA)}</li>");
            if (!string.IsNullOrEmpty(profile.ComparisonFolderB))
                sb.AppendLine($"<li class=\"path\">B: {WebUtility.HtmlEncode(profile.ComparisonFolderB)}</li>");
        }
        sb.AppendLine("</ul></div>");

        var s = result.Statistics;
        sb.AppendLine("<div class=\"card\">");
        sb.AppendLine($"<div class=\"stat\"><b>{s.TotalFilesScanned}</b><span>Archivos</span></div>");
        sb.AppendLine($"<div class=\"stat\"><b>{WebUtility.HtmlEncode(s.TotalScannedFormatted)}</b><span>Espacio analizado</span></div>");
        sb.AppendLine($"<div class=\"stat\"><b>{s.ExactDuplicateGroups}</b><span>Exactos</span></div>");
        sb.AppendLine($"<div class=\"stat\"><b class=\"probable\">{s.ProbableDuplicateGroups}</b><span>Probables</span></div>");
        sb.AppendLine($"<div class=\"stat\"><b>{s.RelatedGroups}</b><span>Relacionados</span></div>");
        sb.AppendLine($"<div class=\"stat\"><b class=\"savings\">{WebUtility.HtmlEncode(s.PotentialSavingsFormatted)}</b><span>Ahorro potencial</span></div>");
        sb.AppendLine("</div>");

        AppendHtmlGroups(sb, "Duplicados exactos (mismo hash SHA-256)", result.ExactDuplicates, "savings");
        AppendHtmlGroups(sb, "Duplicados probables (mismo tamaño + nombre similar)", result.ProbableDuplicates, "probable");
        AppendHtmlGroups(sb, "Archivos relacionados (mismo nombre)", result.RelatedFiles, null, maxGroups: 100);

        sb.AppendLine("<footer>DuplicAitor Detector · Análisis de solo lectura · Ningún archivo fue modificado.</footer>");
        sb.AppendLine("</body></html>");

        await File.WriteAllTextAsync(filePath, sb.ToString(), Encoding.UTF8);
    }

    private static void AppendHtmlGroups(StringBuilder sb, string title, List<DuplicateGroup> groups, string? savingsClass, int maxGroups = int.MaxValue)
    {
        sb.AppendLine($"<h2>{WebUtility.HtmlEncode(title)}</h2>");
        if (groups.Count == 0)
        {
            sb.AppendLine("<p>Ninguno encontrado.</p>");
            return;
        }

        int i = 1;
        foreach (var g in groups.Take(maxGroups))
        {
            var savingsAttr = savingsClass is null ? "" : $" class=\"{savingsClass}\"";
            sb.AppendLine($"<div class=\"card\"><strong>Grupo {i++}</strong> — {g.Files.Count} archivos");
            if (g.RecoverableBytes > 0)
                sb.AppendLine($" · Recuperable: <span{savingsAttr}>{WebUtility.HtmlEncode(g.RecoverableFormatted)}</span>");
            sb.AppendLine("<table><tr><th>Ruta</th><th>Tamaño</th><th>Modificado</th></tr>");
            foreach (var f in g.Files)
            {
                sb.AppendLine($"<tr><td class=\"path\">{WebUtility.HtmlEncode(f.FullPath)}</td><td>{WebUtility.HtmlEncode(f.SizeFormatted)}</td><td>{f.LastWriteTime:yyyy-MM-dd}</td></tr>");
            }
            sb.AppendLine("</table></div>");
        }
        if (groups.Count > maxGroups)
            sb.AppendLine($"<p>… y {groups.Count - maxGroups} grupos más.</p>");
    }

    public async Task ExportJsonAsync(string filePath, ScanResult result, ScanProfile profile)
    {
        var dto = new
        {
            GeneratedAt = DateTime.UtcNow,
            Profile = new
            {
                profile.Name,
                Folders = profile.RootFolders.ToList(),
                profile.IncludeSubfolders,
                profile.CompareTwoLocations,
                profile.ComparisonFolderA,
                profile.ComparisonFolderB
            },
            Statistics = result.Statistics,
            ExactDuplicates = MapGroups(result.ExactDuplicates),
            ProbableDuplicates = MapGroups(result.ProbableDuplicates),
            RelatedFiles = MapGroups(result.RelatedFiles, includeHash: false),
            UniqueCount = result.UniqueFiles.Count
        };

        var json = JsonSerializer.Serialize(dto, JsonOpts);
        await File.WriteAllTextAsync(filePath, json, Encoding.UTF8);
    }

    private static object MapGroups(List<DuplicateGroup> groups, bool includeHash = true) =>
        groups.Select(g => new
        {
            g.Id,
            Type = g.Type.ToString(),
            g.SizeFormatted,
            g.RecoverableFormatted,
            Files = g.Files.Select(f => includeHash
                ? (object)new { f.FullPath, f.SizeBytes, f.SizeFormatted, f.LastWriteTime, f.HashSha256 }
                : new { f.FullPath, f.SizeBytes, f.SizeFormatted })
        });

    public Task ExportPdfAsync(string filePath, ScanResult result, ScanProfile profile)
    {
        var s = result.Statistics;

        Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.Margin(36);
                page.DefaultTextStyle(x => x.FontSize(10).FontColor(Colors.Grey.Darken3));

                page.Header().Column(col =>
                {
                    col.Item().Text("DuplicAitor Detector").FontSize(18).Bold().FontColor(Colors.Blue.Darken2);
                    col.Item().Text("Informe de análisis de duplicados — SOLO LECTURA")
                        .FontSize(11).FontColor(Colors.Grey.Medium);
                    col.Item().Text($"Generado: {DateTime.Now:yyyy-MM-dd HH:mm:ss}").FontSize(9);
                    col.Item().PaddingVertical(6).LineHorizontal(1).LineColor(Colors.Grey.Lighten2);
                });

                page.Content().Column(col =>
                {
                    col.Spacing(10);

                    // Carpetas
                    col.Item().Text("Carpetas analizadas").Bold().FontSize(12);
                    foreach (var f in profile.RootFolders)
                        col.Item().Text($"• {f}").FontSize(9);
                    if (profile.CompareTwoLocations)
                    {
                        if (!string.IsNullOrEmpty(profile.ComparisonFolderA))
                            col.Item().Text($"• A: {profile.ComparisonFolderA}").FontSize(9);
                        if (!string.IsNullOrEmpty(profile.ComparisonFolderB))
                            col.Item().Text($"• B: {profile.ComparisonFolderB}").FontSize(9);
                    }

                    // Stats
                    col.Item().PaddingTop(8).Text("Resumen").Bold().FontSize(12);
                    col.Item().Table(t =>
                    {
                        t.ColumnsDefinition(c =>
                        {
                            c.RelativeColumn();
                            c.RelativeColumn();
                            c.RelativeColumn();
                        });
                        t.Cell().Text($"Archivos: {s.TotalFilesScanned}");
                        t.Cell().Text($"Espacio: {s.TotalScannedFormatted}");
                        t.Cell().Text($"Ahorro pot.: {s.PotentialSavingsFormatted}").Bold();
                        t.Cell().Text($"Exactos: {s.ExactDuplicateGroups}");
                        t.Cell().Text($"Probables: {s.ProbableDuplicateGroups}");
                        t.Cell().Text($"Relacionados: {s.RelatedGroups}");
                    });

                    AppendPdfSection(col, "Duplicados exactos", result.ExactDuplicates, 40);
                    AppendPdfSection(col, "Duplicados probables", result.ProbableDuplicates, 30);
                    AppendPdfSection(col, "Relacionados (mismo nombre)", result.RelatedFiles, 20);
                });

                page.Footer().AlignCenter().Text(txt =>
                {
                    txt.Span("DuplicAitor Detector · Solo lectura · Ningún archivo fue modificado  ·  Página ");
                    txt.CurrentPageNumber();
                    txt.Span(" / ");
                    txt.TotalPages();
                });
            });
        }).GeneratePdf(filePath);

        return Task.CompletedTask;
    }

    private static void AppendPdfSection(ColumnDescriptor col, string title, List<DuplicateGroup> groups, int maxGroups)
    {
        col.Item().PaddingTop(12).Text(title).Bold().FontSize(12).FontColor(Colors.Blue.Darken1);
        if (groups.Count == 0)
        {
            col.Item().Text("Ninguno encontrado.").Italic().FontColor(Colors.Grey.Medium);
            return;
        }

        int n = 0;
        foreach (var g in groups.Take(maxGroups))
        {
            n++;
            col.Item().PaddingTop(6).Text($"Grupo {n} — {g.Files.Count} archivos · Recuperable: {g.RecoverableFormatted}")
                .FontSize(9).SemiBold();
            foreach (var f in g.Files.Take(8))
                col.Item().Text($"  {f.FullPath}  ({f.SizeFormatted})").FontSize(8).FontColor(Colors.Grey.Darken2);
            if (g.Files.Count > 8)
                col.Item().Text($"  … y {g.Files.Count - 8} más").FontSize(8).Italic();
        }
        if (groups.Count > maxGroups)
            col.Item().Text($"… y {groups.Count - maxGroups} grupos más (ver HTML/JSON para el listado completo).")
                .FontSize(8).Italic().FontColor(Colors.Grey.Medium);
    }
}
