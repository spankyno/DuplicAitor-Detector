using System.Text.Json;
using DuplicAitorDetector.Models;

namespace DuplicAitorDetector.Services;

/// <summary>
/// Caché de hashes en JSON. Solo lectura del FS; la caché vive en AppData.
/// Clave: ruta + tamaño + LastWriteTimeUtc ticks.
/// </summary>
public class HashCacheService
{
    private readonly string _cachePath;
    private readonly Dictionary<string, CacheEntry> _entries = new(StringComparer.OrdinalIgnoreCase);
    private readonly object _lock = new();
    private bool _dirty;

    private static readonly JsonSerializerOptions JsonOpts = new()
    {
        WriteIndented = false,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
    };

    public HashCacheService()
    {
        var dir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "DuplicAitorDetector");
        Directory.CreateDirectory(dir);
        _cachePath = Path.Combine(dir, "hash-cache.json");
        Load();
    }

    public int Count
    {
        get { lock (_lock) return _entries.Count; }
    }

    public string? TryGet(string fullPath, long sizeBytes, DateTime lastWriteUtc)
    {
        var key = MakeKey(fullPath, sizeBytes, lastWriteUtc);
        lock (_lock)
        {
            return _entries.TryGetValue(key, out var e) ? e.Hash : null;
        }
    }

    public void Set(string fullPath, long sizeBytes, DateTime lastWriteUtc, string hash)
    {
        var key = MakeKey(fullPath, sizeBytes, lastWriteUtc);
        lock (_lock)
        {
            _entries[key] = new CacheEntry
            {
                Path = fullPath,
                Size = sizeBytes,
                Mtime = lastWriteUtc.Ticks,
                Hash = hash
            };
            _dirty = true;
        }
    }

    public void SaveIfDirty()
    {
        lock (_lock)
        {
            if (!_dirty) return;
            try
            {
                // Limitar tamaño de caché a ~50k entradas (las más recientes por mtime)
                if (_entries.Count > 50_000)
                {
                    var keep = _entries.Values
                        .OrderByDescending(e => e.Mtime)
                        .Take(40_000)
                        .ToList();
                    _entries.Clear();
                    foreach (var e in keep)
                        _entries[MakeKey(e.Path, e.Size, new DateTime(e.Mtime, DateTimeKind.Utc))] = e;
                }

                var list = _entries.Values.ToList();
                var json = JsonSerializer.Serialize(list, JsonOpts);
                File.WriteAllText(_cachePath, json);
                _dirty = false;
            }
            catch
            {
                // Caché no crítica
            }
        }
    }

    private void Load()
    {
        try
        {
            if (!File.Exists(_cachePath)) return;
            var json = File.ReadAllText(_cachePath);
            var list = JsonSerializer.Deserialize<List<CacheEntry>>(json, JsonOpts);
            if (list is null) return;
            lock (_lock)
            {
                _entries.Clear();
                foreach (var e in list)
                {
                    if (string.IsNullOrEmpty(e.Hash) || string.IsNullOrEmpty(e.Path)) continue;
                    var key = MakeKey(e.Path, e.Size, new DateTime(e.Mtime, DateTimeKind.Utc));
                    _entries[key] = e;
                }
            }
        }
        catch
        {
            // Caché corrupta → empezar limpia
        }
    }

    private static string MakeKey(string path, long size, DateTime mtimeUtc)
        => $"{path}|{size}|{mtimeUtc.Ticks}";

    private sealed class CacheEntry
    {
        public string Path { get; set; } = "";
        public long Size { get; set; }
        public long Mtime { get; set; }
        public string Hash { get; set; } = "";
    }
}
