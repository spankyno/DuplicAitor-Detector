using System.Text.Json;
using DuplicAitorDetector.Models;

namespace DuplicAitorDetector.Services;

public class ProfileService
{
    private readonly string _profilesDir;

    private static readonly JsonSerializerOptions JsonOpts = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
    };

    public ProfileService()
    {
        _profilesDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "DuplicAitorDetector", "profiles");
        Directory.CreateDirectory(_profilesDir);
    }

    public string ProfilesDirectory => _profilesDir;

    public async Task SaveAsync(ScanProfile profile, string? fileName = null)
    {
        var name = fileName ?? Sanitize(profile.Name) + ".json";
        if (!name.EndsWith(".json", StringComparison.OrdinalIgnoreCase))
            name += ".json";

        var path = Path.Combine(_profilesDir, name);
        var dto = ToDto(profile);
        var json = JsonSerializer.Serialize(dto, JsonOpts);
        await File.WriteAllTextAsync(path, json);
    }

    public async Task SaveToPathAsync(ScanProfile profile, string fullPath)
    {
        var dto = ToDto(profile);
        var json = JsonSerializer.Serialize(dto, JsonOpts);
        await File.WriteAllTextAsync(fullPath, json);
    }

    public async Task<ScanProfile?> LoadFromPathAsync(string fullPath)
    {
        if (!File.Exists(fullPath)) return null;
        var json = await File.ReadAllTextAsync(fullPath);
        var dto = JsonSerializer.Deserialize<ProfileDto>(json, JsonOpts);
        return dto is null ? null : FromDto(dto);
    }

    public IReadOnlyList<string> ListProfiles()
    {
        if (!Directory.Exists(_profilesDir)) return Array.Empty<string>();
        return Directory.GetFiles(_profilesDir, "*.json")
            .Select(Path.GetFileNameWithoutExtension)
            .Where(n => n is not null)
            .Cast<string>()
            .OrderBy(n => n)
            .ToList();
    }

    private static ProfileDto ToDto(ScanProfile p) => new()
    {
        Name = p.Name,
        RootFolders = p.RootFolders.ToList(),
        IncludeSubfolders = p.IncludeSubfolders,
        ExcludedFolders = p.ExcludedFolders.ToList(),
        IncludedExtensions = p.IncludedExtensions.ToList(),
        ExcludedExtensions = p.ExcludedExtensions.ToList(),
        MinSizeBytes = p.MinSizeBytes,
        MaxSizeBytes = p.MaxSizeBytes,
        NameIncludePattern = p.NameIncludePattern,
        NameExcludePattern = p.NameExcludePattern,
        CompareTwoLocations = p.CompareTwoLocations,
        ComparisonFolderA = p.ComparisonFolderA,
        ComparisonFolderB = p.ComparisonFolderB
    };

    private static ScanProfile FromDto(ProfileDto d)
    {
        var p = new ScanProfile
        {
            Name = d.Name ?? "Perfil",
            IncludeSubfolders = d.IncludeSubfolders,
            ExcludedFolders = d.ExcludedFolders ?? new(),
            IncludedExtensions = d.IncludedExtensions ?? new(),
            ExcludedExtensions = d.ExcludedExtensions ?? new(),
            MinSizeBytes = d.MinSizeBytes,
            MaxSizeBytes = d.MaxSizeBytes,
            NameIncludePattern = d.NameIncludePattern,
            NameExcludePattern = d.NameExcludePattern,
            CompareTwoLocations = d.CompareTwoLocations,
            ComparisonFolderA = d.ComparisonFolderA,
            ComparisonFolderB = d.ComparisonFolderB
        };
        p.RootFolders.Clear();
        foreach (var f in d.RootFolders ?? new())
            p.RootFolders.Add(f);
        return p;
    }

    private static string Sanitize(string name)
    {
        foreach (var c in Path.GetInvalidFileNameChars())
            name = name.Replace(c, '_');
        return string.IsNullOrWhiteSpace(name) ? "perfil" : name.Trim();
    }

    private sealed class ProfileDto
    {
        public string? Name { get; set; }
        public List<string>? RootFolders { get; set; }
        public bool IncludeSubfolders { get; set; } = true;
        public List<string>? ExcludedFolders { get; set; }
        public List<string>? IncludedExtensions { get; set; }
        public List<string>? ExcludedExtensions { get; set; }
        public long? MinSizeBytes { get; set; }
        public long? MaxSizeBytes { get; set; }
        public string? NameIncludePattern { get; set; }
        public string? NameExcludePattern { get; set; }
        public bool CompareTwoLocations { get; set; }
        public string? ComparisonFolderA { get; set; }
        public string? ComparisonFolderB { get; set; }
    }
}
